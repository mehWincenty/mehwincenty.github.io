<?php
/**
 * Podstawowa konfiguracja WordPressa.
 *
 * Skrypt wp-config.php używa tego pliku podczas instalacji.
 * Nie musisz dokonywać konfiguracji przy pomocy przeglądarki internetowej,
 * możesz też skopiować ten plik, nazwać kopię "wp-config.php"
 * i wpisać wartości ręcznie.
 *
 * Ten plik zawiera konfigurację:
 *
 * * ustawień MySQL-a,
 * * tajnych kluczy,
 * * prefiksu nazw tabel w bazie danych,
 * * ABSPATH.
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Ustawienia MySQL-a - możesz uzyskać je od administratora Twojego serwera ** //
/** Nazwa bazy danych, której używać ma WordPress */
define('DB_NAME', 'githubtest');

/** Nazwa użytkownika bazy danych MySQL */
define('DB_USER', 'root');

/** Hasło użytkownika bazy danych MySQL */
define('DB_PASSWORD', '');

/** Nazwa hosta serwera MySQL */
define('DB_HOST', 'localhost');

/** Kodowanie bazy danych używane do stworzenia tabel w bazie danych. */
define('DB_CHARSET', 'utf8mb4');

/** Typ porównań w bazie danych. Nie zmieniaj tego ustawienia, jeśli masz jakieś wątpliwości. */
define('DB_COLLATE', '');

/**#@+
 * Unikatowe klucze uwierzytelniania i sole.
 *
 * Zmień każdy klucz tak, aby był inną, unikatową frazą!
 * Możesz wygenerować klucze przy pomocy {@link https://api.wordpress.org/secret-key/1.1/salt/ serwisu generującego tajne klucze witryny WordPress.org}
 * Klucze te mogą zostać zmienione w dowolnej chwili, aby uczynić nieważnymi wszelkie istniejące ciasteczka. Uczynienie tego zmusi wszystkich użytkowników do ponownego zalogowania się.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '.^;ko8`yZxImbFAh( MZsf&+aOLk1!xiPt^P<4b}e@WqY@w c+-(=VwS;vU=KU_(');
define('SECURE_AUTH_KEY',  '=!cDr@$pGrNi9zn/w lT%/7Q$K1S.,Ln^QE]gG{s_wAM6s}jXumt 42/wpV&4kSG');
define('LOGGED_IN_KEY',    'o]yk:`4XU2bbOZ_C~f@y?aJ/MnCk`$%QilR5uky|!r4QdN!~RnFW[^RV1A32N3_.');
define('NONCE_KEY',        'N24awMPnsA1jw:(`Th FpnEgZW|2/t>K}(V rZ!SzXT SpZN#I0+:g>),E{^9#i(');
define('AUTH_SALT',        '`wNv|`6/INW`j{ry1C2P=naZwdI<jxM7_{/OxHU8<*+>aW0m]$smy9H@H1p;.d~8');
define('SECURE_AUTH_SALT', 'D=Vz2@XoJF[*{hUNF?2h84zl9are-4@$le|z^SsQS#of4x[,N<q$^/ZX}zb0z/Z!');
define('LOGGED_IN_SALT',   'PobAr*vqP?Xz*E7|;q5Ir3B#zV&fUV9a{*@bt-8?e)dHfXzvu_Z4_wrIJu*!L9*<');
define('NONCE_SALT',       ':MJ]nLt$`@&V?0ru<)Q-#deP<OWl`S>qT9J I+ijMo5u,y]E*VPlD#yC9= ;TSJ.');

/**#@-*/

/**
 * Prefiks tabel WordPressa w bazie danych.
 *
 * Możesz posiadać kilka instalacji WordPressa w jednej bazie danych,
 * jeżeli nadasz każdej z nich unikalny prefiks.
 * Tylko cyfry, litery i znaki podkreślenia, proszę!
 */
$table_prefix  = 'ght_';

/**
 * Dla programistów: tryb debugowania WordPressa.
 *
 * Zmień wartość tej stałej na true, aby włączyć wyświetlanie
 * ostrzeżeń podczas modyfikowania kodu WordPressa.
 * Wielce zalecane jest, aby twórcy wtyczek oraz motywów używali
 * WP_DEBUG podczas pracy nad nimi.
 *
 * Aby uzyskać informacje o innych stałych, które mogą zostać użyte
 * do debugowania, przejdź na stronę Kodeksu WordPressa.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* To wszystko, zakończ edycję w tym miejscu! Miłego blogowania! */

/** Absolutna ścieżka do katalogu WordPressa. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Ustawia zmienne WordPressa i dołączane pliki. */
require_once(ABSPATH . 'wp-settings.php');
